<?php
session_start();

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "faculty") {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard</title>

</head>

<body>

    <h1>Welcome, <?php echo $_SESSION["username"]; ?> (Faculty)</h1>
    <p>This is the faculty dashboard.</p>
    <a href="logout.php">Logout</a>
</body>

</html>