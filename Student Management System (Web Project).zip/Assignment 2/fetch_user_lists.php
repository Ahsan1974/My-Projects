<?php

include_once 'db_connection3.php';

$userLists = array(
    'faculty' => '',
    'admin' => '',
    'student' => ''
);

$sql = "SELECT user_id, username, name, email, role FROM users";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

    while ($row = mysqli_fetch_assoc($result)) {
        $userHtml = "<tr>";
        $userHtml .= "<td>" . $row['user_id'] . "</td>";
        $userHtml .= "<td>" . $row['username'] . "</td>";
        $userHtml .= "<td>" . $row['name'] . "</td>";
        $userHtml .= "<td>" . $row['email'] . "</td>";
        $userHtml .= "<td>" . $row['role'] . "</td>";
        $userHtml .= "</tr>";


        switch ($row['role']) {
            case 'faculty':
                $userLists['faculty'] .= $userHtml;
                break;
            case 'admin':
                $userLists['admin'] .= $userHtml;
                break;
            case 'student':
                $userLists['student'] .= $userHtml;
                break;
        }
    }
}

echo json_encode($userLists);

mysqli_close($conn);
