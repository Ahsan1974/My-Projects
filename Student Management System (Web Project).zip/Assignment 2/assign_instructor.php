<?php

include_once 'db_connection3.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $courseId = $_POST['courseId'];
    $instructorId = $_POST['instructorId'];

    if (empty($courseId) || empty($instructorId)) {
        echo "Course ID and instructor ID are required";
    } else {

        $checkSql = "SELECT * FROM courses WHERE course_id = '$courseId'";
        $checkResult = mysqli_query($conn, $checkSql);

        if (mysqli_num_rows($checkResult) > 0) {
            $row = mysqli_fetch_assoc($checkResult);
            if (!empty($row['instructor_id'])) {
                echo "Course already has an instructor assigned";
            } else {

                $updateSql = "UPDATE courses SET instructor_id = '$instructorId' WHERE course_id = '$courseId'";

                if (mysqli_query($conn, $updateSql)) {
                    echo "Instructor assigned successfully";
                } else {
                    echo "Error updating course: " . mysqli_error($conn);
                }
            }
        } else {
            echo "Course not found";
        }
    }
}

mysqli_close($conn);
