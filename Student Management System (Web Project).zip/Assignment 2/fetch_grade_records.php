<?php

include_once 'db_connection3.php';

$sql = "SELECT course_title, assignment_name, grade, remarks FROM grade_records";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

    while ($row = mysqli_fetch_assoc($result)) {

        echo "<tr>";
        echo "<td>" . $row['course_title'] . "</td>";
        echo "<td>" . $row['assignment_name'] . "</td>";
        echo "<td>" . $row['grade'] . "</td>";
        echo "<td>" . $row['remarks'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>No grade records found</td></tr>";
}

mysqli_close($conn);
