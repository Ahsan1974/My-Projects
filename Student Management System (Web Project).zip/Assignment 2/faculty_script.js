$(document).ready(function () {

    function fetchCourses() {

        $.ajax({
            url: 'fetch_courses.php',
            type: 'GET',
            success: function (response) {

                $('#courseSelect').html(response);
            },
            error: function (xhr, status, error) {
                console.error('Error fetching courses:', error);
            }
        });
    }

    fetchCourses();

    function fetchAttendance(courseId) {

        $.ajax({
            url: 'fetch_attendance.php',
            type: 'POST',
            data: { courseId: courseId },
            success: function (response) {

                $('#attendanceRecords').html(response);
            },
            error: function (xhr, status, error) {
                console.error('Error fetching attendance:', error);
            }
        });
    }

    function fetchGrades(courseId) {

        $.ajax({
            url: 'fetch_grades.php',
            type: 'POST',
            data: { courseId: courseId },
            success: function (response) {

                $('#gradeRecords').html(response);
            },
            error: function (xhr, status, error) {
                console.error('Error fetching grades:', error);
            }
        });
    }

    function fetchStudentList(courseId) {

        $.ajax({
            url: 'fetch_student_list.php',
            type: 'POST',
            data: { courseId: courseId },
            success: function (response) {

                $('#studentListItems').html(response);
            },
            error: function (xhr, status, error) {
                console.error('Error fetching student list:', error);
            }
        });
    }

    $('#courseSelect').change(function () {
        var courseId = $(this).val();
        if (courseId !== '') {

            $('#attendanceSection').show();
            $('#gradingSection').show();
            $('#studentList').show();

            fetchAttendance(courseId);
            fetchGrades(courseId);
            fetchStudentList(courseId);
        } else {

            $('#attendanceSection').hide();
            $('#gradingSection').hide();
            $('#studentList').hide();
        }
    });

    $('#submitAttendanceBtn').click(function () {

    });
});
