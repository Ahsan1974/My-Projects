<?php

include_once 'db_connection3.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['userId'])) {

    $userId = mysqli_real_escape_string($conn, $_POST['userId']);

    $sql = "DELETE FROM users WHERE user_id = '$userId'";

    if (mysqli_query($conn, $sql)) {
        echo "User deleted successfully";
    } else {
        echo "Error deleting user: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request";
}

mysqli_close($conn);
