<?php

include_once 'db_connection3.php';

$sql = "SELECT instructor_id, name FROM instructors";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

    while ($row = mysqli_fetch_assoc($result)) {

        echo "<option value='" . $row['instructor_id'] . "'>" . $row['name'] . "</option>";
    }
} else {
    echo "<option value=''>No instructors found</option>";
}

mysqli_close($conn);
