<?php

include_once 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST['courseId'])) {

        $courseId = mysqli_real_escape_string($conn, $_POST['courseId']);

        $sql = "SELECT s.name AS student_name, g.assignment_name, g.grade
                FROM grades g
                INNER JOIN students s ON g.student_id = s.student_id
                WHERE g.course_id = $courseId";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['student_name'] . "</td>";
                echo "<td>" . $row['assignment_name'] . "</td>";
                echo "<td>" . $row['grade'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='3'>No grade records found</td></tr>";
        }

        mysqli_close($conn);
    } else {

        http_response_code(400);
        echo "Bad Request: courseId parameter is missing";
    }
} else {

    http_response_code(405);
    echo "Method Not Allowed";
}
