<?php
include_once 'db_connection3.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $courseTitle = $_POST['courseTitle'];
    if (empty($courseTitle)) {
        echo "Course title is required";
    } else {

        $sql = "INSERT INTO courses (course_title) VALUES ('$courseTitle')";

        if (mysqli_query($conn, $sql)) {
            echo "Course added successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}


mysqli_close($conn);
