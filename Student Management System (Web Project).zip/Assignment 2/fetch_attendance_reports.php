<?php

include_once 'db_connection3.php';

$sql = "SELECT * FROM attendance_reports";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

    while ($row = mysqli_fetch_assoc($result)) {

        echo "<div class='attendance-report'>";
        echo "<h3>Course: " . $row['course_name'] . "</h3>";
        echo "<p>Date: " . $row['date'] . "</p>";
        echo "<p>Attendance: " . $row['attendance'] . "</p>";
        echo "</div>";
    }
} else {
    echo "No attendance reports found";
}

mysqli_close($conn);
