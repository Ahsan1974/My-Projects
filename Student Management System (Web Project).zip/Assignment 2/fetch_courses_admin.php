<?php

include_once 'db_connection3.php';

$sql = "SELECT course_id, course_title FROM courses";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

    while ($row = mysqli_fetch_assoc($result)) {

        echo "<option value='" . $row['course_id'] . "'>" . $row['course_title'] . "</option>";
    }
} else {
    echo "<option value=''>No courses found</option>";
}

mysqli_close($conn);
