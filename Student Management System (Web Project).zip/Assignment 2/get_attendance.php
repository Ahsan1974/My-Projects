<?php

session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {

    header("Location: login.php");
    exit();
}

include_once 'db_connection.php';

$student_id = $_SESSION['user_id'];

$sql = "SELECT * FROM attendance WHERE student_id = ?";

$stmt = mysqli_prepare($conn, $sql);

if ($stmt) {

    mysqli_stmt_bind_param($stmt, "i", $student_id);

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {

        echo "<h2>Attendance Records</h2>";
        echo "<table class='table'>";
        echo "<thead><tr><th>Course</th><th>Date</th><th>Status</th></tr></thead>";
        echo "<tbody>";

        while ($row = mysqli_fetch_assoc($result)) {

            echo "<tr>";
            echo "<td>" . $row['course_id'] . "</td>";
            echo "<td>" . $row['date'] . "</td>";
            echo "<td>" . $row['status'] . "</td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
    } else {
        echo "No attendance records found.";
    }


    mysqli_stmt_close($stmt);
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);
