<?php

include_once 'db_connection2.php';

if ($_SERVER["REQUEST_METHOD"] == "GET") {

    $sql = "SELECT course_id, title FROM courses";

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {

        $options = '<option value="">-- Select Course --</option>';
        while ($row = mysqli_fetch_assoc($result)) {
            $options .= '<option value="' . $row["course_id"] . '">' . $row["title"] . '</option>';
        }
        echo $options;
    } else {
        echo '<option value="">No courses available</option>';
    }

    mysqli_close($conn);
} else {

    http_response_code(405);
    echo "Method Not Allowed";
}
