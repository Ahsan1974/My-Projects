$(document).ready(function () {

    $.ajax({
        url: 'get_attendance.php',
        type: 'GET',
        success: function (response) {
            $('#attendance_records').html(response);
        }
    });

    $.ajax({
        url: 'get_grades.php',
        type: 'GET',
        success: function (response) {
            $('#grade_records').html(response);
        }
    });

    $('#edit_profile_btn').click(function () {

        $('#profile_details').html('Profile details form will be displayed here');
    });
});
