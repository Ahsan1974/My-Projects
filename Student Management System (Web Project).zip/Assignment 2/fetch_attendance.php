<?php
// Include database connection
include_once 'db_connection2.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST['courseId'])) {

        $courseId = mysqli_real_escape_string($conn, $_POST['courseId']);

        $sql = "SELECT s.name AS student_name, a.status
                FROM attendance a
                INNER JOIN students s ON a.student_id = s.student_id
                WHERE a.course_id = $courseId";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['student_name'] . "</td>";
                echo "<td>" . $row['status'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='2'>No attendance records found</td></tr>";
        }


        mysqli_close($conn);
    } else {

        http_response_code(400);
        echo "Bad Request: courseId parameter is missing";
    }
} else {

    http_response_code(405);
    echo "Method Not Allowed";
}
