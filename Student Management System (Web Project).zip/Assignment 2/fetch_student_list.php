<?php

include_once 'db_connection2.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST['courseId'])) {

        $courseId = mysqli_real_escape_string($conn, $_POST['courseId']);

        $sql = "SELECT s.name AS student_name
                FROM students s
                INNER JOIN enrollments e ON s.student_id = e.student_id
                WHERE e.course_id = $courseId";


        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<li class='list-group-item'>" . $row['student_name'] . "</li>";
            }
        } else {
            echo "<li class='list-group-item'>No students enrolled in this course</li>";
        }


        mysqli_close($conn);
    } else {

        http_response_code(400);
        echo "Bad Request: courseId parameter is missing";
    }
} else {

    http_response_code(405);
    echo "Method Not Allowed";
}
