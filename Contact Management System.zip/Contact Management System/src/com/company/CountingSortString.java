package com.company;

import java.util.Arrays;

public class CountingSortString {
    public static void countingSort(String[] arr) {
        if (arr == null || arr.length == 0) {
            return; // Nothing to sort
        }

        // Find the minimum and maximum characters in the strings to determine the range
        int minChar = Integer.MAX_VALUE;
        int maxChar = Integer.MIN_VALUE;

        for (String str : arr) {
            for (char c : str.toCharArray()) {
                minChar = Math.min(minChar, c);
                maxChar = Math.max(maxChar, c);
            }
        }
        int range = maxChar - minChar + 1;

        // Initialize a counting array
        int[] count = new int[range];
        Arrays.fill(count, 0);

        // Count the occurrences of each character in the counting array
        for (String str : arr) {
            for (char c : str.toCharArray()) {
                int index = c - minChar;
                count[index]++;
            }
        }

        // Calculate the cumulative sum of the counting array
        for (int i = 1; i <= range; i++) {
            count[i] += count[i - 1];
        }

        // Initialize an output array
        String[] output = new String[arr.length];

        // Place each string in the correct position in the output array
        for (int i = arr.length - 1; i >= 0; i--) {
            for (char c : arr[i].toCharArray()) {
                int index = c - minChar;
                output[count[index] - 1] = arr[i];
                count[index]--;
            }
        }

        // Copy the sorted strings from the output array back to the input array
        System.arraycopy(output, 0, arr, 0, arr.length);
    }
    public static void main(String[] args) {
        String[] arr = {"ihab", "abid", "afif", "fadi", "adib", "hadi", "ibad"};

        // Call countingSort to sort the array of strings
        countingSort(arr);

        // Print the sorted array
        System.out.println("Sorted Array:");
        for (String str : arr) {
            System.out.print(str + " ");
        }

    }
}
