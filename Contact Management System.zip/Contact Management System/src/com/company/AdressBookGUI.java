//package com.company;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.io.BufferedReader;
//import java.io.FileNotFoundException;
//import java.io.FileReader;
//import java.io.IOException;
//
//public class AdressBookGUI extends JFrame implements ActionListener {
//    public Container c;
//    public JLabel title;
//    public JButton add;
//    public JButton search;
//    public JButton delete;
//    public JButton exit;
//    public JButton show;
//    public AdressBookGUI(){
//        setTitle("Contact Book");
//        setBounds(300,90,700,600);
//        setDefaultCloseOperation(EXIT_ON_CLOSE);
//        setResizable(false);
////        setBackground(Color.BLUE);
//        c=getContentPane();
//        c.setLayout(null);
//
//        c.setBackground(Color.CYAN);
//
//        title=new JLabel("Contact Book");
//        title.setFont(new Font("Arial",Font.PLAIN,30));
//        title.setSize(300,30);
//        title.setLocation(250,30);
//        c.add(title);
//
//        add=new JButton("Add Contact");
//        add.setFont(new Font("Arial",Font.PLAIN,20));
//        add.setSize(200,40);
//        add.setLocation(245,150);
//        add.addActionListener(this);
//        setFocusable(true);
//        c.add(add);
//
//        search=new JButton("Search Contact");
//        search.setFont(new Font("Arial",Font.PLAIN,20));
//        search.setSize(200,40);
//        search.setLocation(245,250);
//        search.addActionListener(this);
//        setFocusable(true);
//        c.add(search);
//
//        delete=new JButton("Delete Contact");
//        delete.setFont(new Font("Arial",Font.PLAIN,20));
//        delete.setSize(200,40);
//        delete.setLocation(245,350);
//        delete.addActionListener(this);
//        setFocusable(true);
//        c.add(delete);
//
//        show=new JButton("Show Contact");
//        show.setFont(new Font("Arial",Font.PLAIN,20));
//        show.setSize(200,40);
//        show.setLocation(245,450);
//        show.addActionListener(this);
//        setFocusable(true);
//        c.add(show);
//
//
//
//
//
//
//        setVisible(true);
//    }
//
//
//    public static void main(String[] args) {
//        AdressBookGUI adressBookGUI=new AdressBookGUI();
////        AddContact addContact=new AddContact();
//
//
//    }
//
//    @Override
//    public void actionPerformed(ActionEvent e) {
//        if (e.getSource()==add){
//            dispose();
//            new AddContact();
//
//        } else if (e.getSource()==search) {
//
//            String s1=JOptionPane.showInputDialog("Enter name to search ");
//            try {
//                BufferedReader reader=new BufferedReader(new FileReader("PersonText.txt"));
//                String line;
//                int lineNumber=1;
//                while ((line=reader.readLine())!=null){
//                    if (line.contains(s1)){
//                        System.out.println(lineNumber);
////                        new SearchContact();
//
//
//                    }
//                    lineNumber++;
//
//                }
//            } catch (FileNotFoundException ex) {
//                throw new RuntimeException(ex);
//            } catch (IOException ex) {
//                throw new RuntimeException(ex);
//            }
//
//
//        } else if (e.getSource()==delete) {
//            String s2=JOptionPane.showInputDialog("Enter name to delete ");
//        }
//
//    }
//}
