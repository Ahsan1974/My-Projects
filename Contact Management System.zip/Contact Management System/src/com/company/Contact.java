package com.company;

import java.util.ArrayList;

public class Contact {
    public String name, phnNumber, address;

    public Contact(String name, String phnNumber, String address) {
        this.name = name;
        this.phnNumber = phnNumber;
        this.address = address;
    }

    public static String returnTextFeildText(ArrayList<Contact> contacts) {
        StringBuilder text = new StringBuilder();
        for (Contact contact : contacts) {
            text.append("Name: ").append(contact.name).append("\n").append("Phone Number: ").
                    append(contact.phnNumber).append("\n").append("Address: ").append(contact.address).
                    append("\n\n");
        }
        return text.toString();
    }

    public static ArrayList<Contact> getContactsWithName(String search, ArrayList<Contact> contacts) {
        ArrayList<Contact> contactsWithSearch = new ArrayList<>();
        for (Contact contact : contacts) {
            if (contact.name.toLowerCase().contains(search.toLowerCase())) {
                contactsWithSearch.add(contact);
            }
        }
        return contactsWithSearch;
    }
}
