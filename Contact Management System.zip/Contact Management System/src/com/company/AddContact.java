package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddContact extends JFrame implements ActionListener {
    public Container c;
    public JLabel add;
    public JLabel name;
    public JLabel address;
    public JLabel number;
    public JTextField nameText;
    public JTextField addressText;
    public JTextField numberText;
    public JButton save;
    public JButton back;

    public AddContact() {
        setTitle("Contact Book");
        setBounds(550,90,500,500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        c = getContentPane();
        c.setLayout(null);

//        c.setBackground(new Color(100, 204, 197));

        add = new JLabel("Add Contact");
        add.setFont(new Font("Arial", Font.PLAIN, 25));
        add.setSize(300, 25);
        add.setLocation(150, 30);
        c.add(add);

        name = new JLabel("Name");
        name.setFont(new Font("Arial", Font.PLAIN, 20));
        name.setSize(100, 30);
        name.setLocation(110, 100);
        c.add(name);

        nameText = new JTextField();
        nameText.setFont(new Font("Arial", Font.PLAIN, 25));
        nameText.setSize(190, 30);
        nameText.setLocation(200, 100);
        c.add(nameText);

        address = new JLabel("Address");
        address.setFont(new Font("Arial", Font.PLAIN, 20));
        address.setSize(100, 30);
        address.setLocation(110, 200);
        c.add(address);

        addressText = new JTextField();
        addressText.setFont(new Font("Arial", Font.PLAIN, 25));
        addressText.setSize(190, 30);
        addressText.setLocation(200, 200);
        c.add(addressText);

        number = new JLabel("Number");
        number.setFont(new Font("Arial", Font.PLAIN, 20));
        number.setSize(100, 30);
        number.setLocation(110, 300);
        c.add(number);

        numberText = new JTextField();
        numberText.setFont(new Font("Arial", Font.PLAIN, 25));
        numberText.setSize(190, 30);
        numberText.setLocation(200, 300);
        c.add(numberText);

        save = new JButton("Save");
        save.setFont(new Font("Arial", Font.PLAIN, 15));
        save.setSize(120, 30);
        save.setLocation(220, 400);
        save.addActionListener(this);
        save.setFocusable(true);
        c.add(save);

        setVisible(true);
    }

    public static void main(String[] args) {
        AddContact add = new AddContact();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == save) {
            Filing.writeLineInFile(nameText.getText() + "," + numberText.getText() + "," + addressText.getText());
            dispose();
            new ContactsBook();
        }
    }
}
