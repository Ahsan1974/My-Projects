package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class ContactsBook extends JFrame{
    private JPanel panel1;
    private JTextField searchNumber;
    private JTextArea Contacts;
    private JButton addNewContactButton;
    private JButton editButton;
    private JButton searchButton;
    private JButton exitButton;
    private JButton deleteButton;
    private JButton reloadButton;
    ArrayList<Contact> contactsList = Filing.readFile();
    ArrayList<Contact> contactsFromSearch;

    public ContactsBook(){
        setContentPane(panel1);
        setTitle("Contact Book");

        setBounds(550,90,500,500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        panel1.setBackground(Color.lightGray);
        setVisible(true);
        addNewContactButton.setFocusable(true);
        editButton.setFocusable(true);
        searchButton.setFocusable(true);
        reloadButton.setFocusable(true);
        exitButton.setFocusable(true);
        Contacts.setText(Contact.returnTextFeildText(contactsList));
        Contacts.setEditable(false);

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String search = searchNumber.getText();
                contactsFromSearch = Contact.getContactsWithName(search, contactsList);
                if (contactsFromSearch.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No contact found with this name");
                } else {
                    Contacts.setText(Contact.returnTextFeildText(contactsFromSearch));
                }
            }
        });
        reloadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {

                Contacts.setText("");
                Contacts.setText(Contact.returnTextFeildText(contactsList));
            }
        });
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        addNewContactButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new AddContact();
            }
        });
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (contactsFromSearch == null) return;
                if (contactsFromSearch.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No contact found with this name");
                    return;
                }
                if (contactsFromSearch.size() > 1) {
                    JOptionPane.showMessageDialog(null, "Please select one contact to edit");
                    return;
                }
                dispose();
                new EditContact(contactsFromSearch.get(0), contactsList);
            }
        });
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (contactsFromSearch == null) return;
                if (contactsFromSearch.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No contact found with this name");
                    return;
                }
                if (contactsFromSearch.size() > 1) {
                    JOptionPane.showMessageDialog(null, "Please select one contact to delete");
                    return;
                }
                contactsList.remove(contactsFromSearch.get(0));
                Filing.updateFile(contactsList);
                Contacts.setText(Contact.returnTextFeildText(contactsList));
            }
        });
    }

    public static void main(String[] args) {
        new ContactsBook();
    }
}
