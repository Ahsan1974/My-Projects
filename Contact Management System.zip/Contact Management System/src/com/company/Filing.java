package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Filing {
    public static void main(String[] args) {
        try {
            File file = new File("contacts.txt");
            if (file.createNewFile()) {
                System.out.println("File created successfully");
            } else {
                System.out.println("File already exists");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        writeLineInFile("Hussain Mustafa,03352330955,Karachi");
        writeLineInFile("Hussain Mustafa,03352330955,Karachi");
        writeLineInFile("Hussain Mustafa,03352330955,Karachi");
        readFile();
    }

    public static void writeLineInFile(String line) {
        //write a line in the contacts file
        try {
            FileWriter writer = new FileWriter("contacts.txt", true);
            writer.write(line + "\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Contact> readFile() {
        //read the contacts file
        ArrayList<Contact> contactsList = new ArrayList<>();

        try {
            File file = new File("contacts.txt");
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] lineData = line.split(",");
                Contact contact = new Contact(lineData[0], lineData[1], lineData[2]);
                contactsList.add(contact);
                System.out.println(line);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return contactsList;
    }

    public static void updateFile(ArrayList<Contact> contactsList) {
        try {
            FileWriter writer = new FileWriter("contacts.txt");
            for (Contact contact : contactsList) {
                writer.write(contact.name + "," + contact.phnNumber + "," + contact.address + "\n");
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
