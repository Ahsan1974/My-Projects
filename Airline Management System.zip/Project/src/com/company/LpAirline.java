package com.company;

import model.Datasource;
import model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LpAirline extends JFrame implements ActionListener {
    private Container b;
    private JLabel title;
    private JLabel LPassword;
    private JPasswordField tLPassword;
    private JLabel LEmail;
    private JTextField tLEmail;
    private JButton can;
    private JButton signup;
    private JButton login;
    private JLabel reg;


    public LpAirline(){
        setTitle("Login");
        setBounds(300,90,900,700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(true);

        b=getContentPane();
        b.setLayout(null);

        title=new JLabel("Welcome To Airline Reservation System");
        title.setFont(new Font("Arial",Font.PLAIN,30));
        title.setSize(700,30);
        title.setLocation(200,20);
        b.add(title);

        title=new JLabel("Login");
        title.setFont(new Font("Arial",Font.PLAIN,30));
        title.setSize(300,30);
        title.setLocation(400,80);
        b.add(title);

        LPassword=new JLabel("Password");
        LPassword.setFont(new Font("Arial",Font.PLAIN,30));
        LPassword.setSize(150,40);
        LPassword.setLocation(300,250);
        b.add(LPassword);

        tLPassword=new JPasswordField();
        tLPassword.setFont(new Font("Arial",Font.PLAIN,30));
        tLPassword.setSize(300,40);
        tLPassword.setLocation(450,250);
        b.add(tLPassword);

        LEmail=new JLabel("Email");
        LEmail.setFont(new Font("Arial",Font.PLAIN,30));
        LEmail.setSize(150,40);
        LEmail.setLocation(300,150);
        b.add(LEmail);

        tLEmail=new JTextField();
        tLEmail.setFont(new Font("Arial",Font.PLAIN,30));
        tLEmail.setSize(300,40);
        tLEmail.setLocation(450,150);
        b.add(tLEmail);

        signup=new JButton("Sign Up");
        signup.setFont(new Font("Arial",Font.PLAIN,15));
        signup.setSize(100,40);
        signup.setLocation(700,500);
        b.add(signup);

        can=new JButton("Cancel");
        can.setFont(new Font("Arial",Font.PLAIN,15));
        can.setSize(100,40);
        can.setLocation(100,500);
        b.add(can);

        login=new JButton("Login");
        login.setFont(new Font("Arial",Font.PLAIN,15));
        login.setSize(100,40);
        login.setLocation(400,500);
        b.add(login);

        reg=new JLabel("");
        reg.setFont(new Font("Arial",Font.PLAIN,20));
        reg.setSize(400,20);
        reg.setLocation(300,450);
        b.add(reg);

        can.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        signup.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new SignUpPage();
            }
        });
        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userData();
            }
        });

        setVisible(true);


    }
    public void userData(){
        User user;
        String Password= new String(tLPassword.getPassword());
        String Email=tLEmail.getText();
        if(Password.isEmpty()||Email.isEmpty()){
            JOptionPane.showMessageDialog(this,"Please Enter all Fields","Try Again",JOptionPane.ERROR_MESSAGE);
            return;
        }
        Datasource ds = new Datasource();
        boolean open = ds.openDB();
        user = ds.findUser(Email, Password);
        if (user != null){
            reg.setText("Login Successfully.....");
            dispose();
            new Main_page(user.getId());

        }else {
            JOptionPane.showMessageDialog(this,"Failed to login. Enter correct email and password",
                    "Try Again",JOptionPane.ERROR_MESSAGE);
            }
        boolean close = ds.closeDB();

    }

    public static void main(String[] args) {
        new LpAirline();

    }


    @Override
    public void actionPerformed(ActionEvent e) {


    }
}
