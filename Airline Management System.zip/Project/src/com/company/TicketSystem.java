package com.company;

import model.Datasource;
import model.Flight;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TicketSystem extends JFrame implements ActionListener {
    public int user;
    private JLabel title;
    private Container c;
    private JLabel departure;
    private JLabel name;
    private JTextField tname;
    private JComboBox tdeparture;
    private JLabel arrival;
    private JComboBox tarrival;
    private JLabel passenger;
    private JRadioButton adults;
    private JRadioButton childs;
    private JRadioButton infants;
    private JTextField adultText;
    private JTextField childsText;
    private JTextField infantsText;
    private JLabel wheel;
    private JRadioButton yes;
    private JRadioButton no;
    private ButtonGroup wcgp;
    private JLabel aclass;
    private JRadioButton economy;
    private JRadioButton business;
    private ButtonGroup cgp;
    private JLabel payment;
    private JComboBox getPayment;
    private JButton sub;
    private JLabel bag;
    private JComboBox weight;
    private JLabel res;
    private JTextArea tout;
    private JTextArea resadd;
    private JButton seating;
    private String cities[] = {
            "Karachi", "Lahore", "Islamabad",
            "Quetta", "Dubai", "New York City", "Kuala Lumpur",
            "Swat", "London", "Istanbul", "Moscow"
    };
    private String arrivals[] = {
            "Karachi", "Lahore", "Islamabad",
            "Quetta", "Dubai", "New York City", "Kuala Lumpur",
            "Swat", "London", "Istanbul", "Moscow"
    };
    private String pay[] = {
            "Credit Card", "Debit Card", "Jazz Cash", "Easy Paisa"
    };
    private String baggage[]={
            "10","20","30","40","50"
    };


    public TicketSystem(int user) {
        this.user = user;

        setTitle("Ticket System");
        setBounds(300, 90, 900, 700);
//        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        c = getContentPane();
        c.setLayout(null);

        title = new JLabel("Ticket Booking");
        title.setFont(new Font("Arial", Font.PLAIN, 30));
        title.setSize(300, 30);
        title.setLocation(300, 30);
        c.add(title);

//        name = new JLabel("Name");
//        name.setFont(new Font("Arial", Font.PLAIN, 20));
//        name.setSize(100, 20);
//        name.setLocation(100, 100);
//        c.add(name);
//
//        tname = new JTextField();
//        tname.setFont(new Font("Arial", Font.PLAIN, 18));
//        tname.setSize(200, 20);
//        tname.setLocation(200, 100);
//        c.add(tname);

        departure = new JLabel("Departure");
        departure.setFont(new Font("Arial", Font.PLAIN, 20));
        departure.setSize(100, 20);
        departure.setLocation(100, 150);
        c.add(departure);

        tdeparture = new JComboBox(cities);
        tdeparture.setFont(new Font("Arial", Font.PLAIN, 18));
        tdeparture.setSize(200, 20);
        tdeparture.setLocation(200, 150);
        c.add(tdeparture);

        arrival = new JLabel("Arrival");
        arrival.setFont(new Font("Arial", Font.PLAIN, 20));
        arrival.setSize(100, 20);
        arrival.setLocation(100, 200);
        c.add(arrival);

        tarrival = new JComboBox(arrivals);
        tarrival.setFont(new Font("Arial", Font.PLAIN, 18));
        tarrival.setSize(200, 20);
        tarrival.setLocation(200, 200);
        c.add(tarrival);

        passenger = new JLabel("Passenger");
        passenger.setFont(new Font("Arial", Font.PLAIN, 20));
        passenger.setSize(100, 20);
        passenger.setLocation(100, 250);
        c.add(passenger);

        adults = new JRadioButton("Adult");
        adults.setFont(new Font("Arial", Font.PLAIN, 15));
        adults.setSelected(false);
        adults.setSize(75, 20);
        adults.setLocation(200, 250);
        c.add(adults);

        adultText=new JTextField();
        adultText.setFont(new Font("Arial",Font.PLAIN,15));
        adultText.setSize(50,20);
        adultText.setLocation(200,300);
        adultText.setText("0");
        c.add(adultText);

        childs = new JRadioButton("Child");
        childs.setFont(new Font("Arial", Font.PLAIN, 15));
        childs.setSelected(false);
        childs.setSize(75, 20);
        childs.setLocation(275, 250);
        c.add(childs);

        childsText=new JTextField();
        childsText.setFont(new Font("Arial",Font.PLAIN,15));
        childsText.setSize(50,20);
        childsText.setLocation(275,300);
        childsText.setText("0");
        c.add(childsText);

        infants = new JRadioButton("Infant");
        infants.setFont(new Font("Arial", Font.PLAIN, 15));
        infants.setSelected(false);
        infants.setSize(75, 20);
        infants.setLocation(350, 250);
        c.add(infants);

        infantsText=new JTextField();
        infantsText.setFont(new Font("Arial",Font.PLAIN,15));
        infantsText.setSize(50,20);
        infantsText.setLocation(350,300);
        infantsText.setText("0");
        c.add(infantsText);

        wheel = new JLabel("Wheelchair");
        wheel.setFont(new Font("Arial", Font.PLAIN, 20));
        wheel.setSize(100, 20);
        wheel.setLocation(100, 350);
        c.add(wheel);

        yes = new JRadioButton("Yes");
        yes.setFont(new Font("Arial", Font.PLAIN, 15));
        yes.setSelected(false);
        yes.setSize(75, 20);
        yes.setLocation(200, 350);
        c.add(yes);

        no = new JRadioButton("No");
        no.setFont(new Font("Arial", Font.PLAIN, 15));
        no.setSelected(true);
        no.setSize(75, 20);
        no.setLocation(300, 350);
        c.add(no);

        wcgp = new ButtonGroup();
        wcgp.add(yes);
        wcgp.add(no);

        aclass = new JLabel("Class");
        aclass.setFont(new Font("Arial", Font.PLAIN, 20));
        aclass.setSize(100, 20);
        aclass.setLocation(100, 400);
        c.add(aclass);

        economy = new JRadioButton("Economy");
        economy.setFont(new Font("Arial", Font.PLAIN, 15));
        economy.setSelected(false);
        economy.setSize(100, 20);
        economy.setLocation(200, 400);
        c.add(economy);

        business = new JRadioButton("Business");
        business.setFont(new Font("Arial", Font.PLAIN, 15));
        business.setSelected(false);
        business.setSize(100, 20);
        business.setLocation(300, 400);
        c.add(business);

        cgp = new ButtonGroup();
        cgp.add(economy);
        cgp.add(business);

        payment = new JLabel("Payment");
        payment.setFont(new Font("Arial", Font.PLAIN, 20));
        payment.setSize(100, 20);
        payment.setLocation(100, 450);
        c.add(payment);

        getPayment = new JComboBox(pay);
        getPayment.setFont(new Font("Arial", Font.PLAIN, 18));
        getPayment.setSize(250, 20);
        getPayment.setLocation(200, 450);
        c.add(getPayment);

        bag=new JLabel("Baggage");
        bag.setFont(new Font("Arial",Font.PLAIN,20));
        bag.setSize(100,20);
        bag.setLocation(100,500);
        c.add(bag);

        weight=new JComboBox(baggage);
        weight.setFont(new Font("Arial",Font.PLAIN,15));
        weight.setSize(100,20);
        weight.setLocation(200,500);
        c.add(weight);

        sub = new JButton("Submit");
        sub.setFont(new Font("Arial", Font.PLAIN, 15));
        sub.setSize(100, 20);
        sub.setLocation(100, 550);
        sub.addActionListener(this);
        c.add(sub);

        seating=new JButton("Seating ");
        seating.setFont(new Font("Arial",Font.PLAIN,15));
        seating.setSize(100,20);
        seating.setLocation(300,550);
        seating.addActionListener(this);
        c.add(seating);

        res=new JLabel("");
        res.setFont(new Font("Arial",Font.PLAIN,20));
        res.setSize(500,25);
        res.setLocation(100,600);
        c.add(res);

        resadd=new JTextArea();
        resadd.setFont(new Font("Arial",Font.PLAIN,15));
        resadd.setLocation(200,75);
        resadd.setLocation(580,175);
        resadd.setLineWrap(true);
        c.add(resadd);

        tout = new JTextArea();
        tout.setFont(new Font("Arial", Font.PLAIN, 15));
        tout.setSize(300, 400);
        tout.setLocation(500, 100);
        tout.setLineWrap(true);
        tout.setEditable(false);
        c.add(tout);



        setVisible(true);


    }

    public static void main(String[] args) {
        new TicketSystem(1);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        boolean buttonClicked = false;
        Datasource ds = new Datasource();
        boolean open = ds.openDB();
        Flight flight = ds.getFlight(tdeparture.getSelectedItem().toString()
                , tarrival.getSelectedItem().toString());
        int seatClass;
        if(economy.isSelected()) seatClass = Datasource.ECONOMY_CLASS;
        else seatClass = Datasource.BUSINESS_CLASS;
        int adult = Integer.parseInt(adultText.getText());
        int child = Integer.parseInt(childsText.getText());
        int infant = Integer.parseInt(infantsText.getText());
        int seatCount = adult + child + infant;
        int wheelchair = 0;
        if(yes.isSelected()) wheelchair = 1;
        else wheelchair = 0;

        if(e.getSource()==sub){
            if (!buttonClicked){
                buttonClicked = true;

                String data1;
//            String data="Name: "+tname.getText()+"\n";
                int i;
                String data3;
                if(yes.isSelected()) {
                    data1 = "Wheel Chair: Yes" + "\n";
                } else {
                    data1 = "Wheel Chair: No" + "\n";
                }
                String data2="Departure From: "+tdeparture.getSelectedItem()+"\n"+
                        "Arrival To: "+tarrival.getSelectedItem()+"\n";
                if(economy.isSelected()) {
                    data3 = "Class: Economy" + "\n";
                }
                else {
                    data3 = "Class: Business" + "\n";
                }
                String data4="Payment By: "+getPayment.getSelectedItem()+"\n";

                int initialPrice = flight.getTicketPrice();
                String data5="Baggage: "+weight.getSelectedItem()+"/Kg"+"\n";
                String data6="Adults: "+adultText.getText()+"\n";
                String data7="Children: "+childsText.getText()+"\n";
                String data8="Infants: "+infantsText.getText()+"\n";
                String data9="Charges per person: "+"\n"+"Adult=" + (initialPrice * adult) +"\n"+
                        "Child="+(initialPrice * 0.9 * child)+"\n"+"Infants="+(initialPrice * 0.85 * infant)+
                        "\n"+"***Passenger***"+"\n";
                int TotalBill= (int) ((initialPrice * adult) + (initialPrice * 0.9 * child) + (initialPrice * 0.85 * infant));
                String data10="Total Price Of Tickets: "+TotalBill;

                int emptySeats = ds.getSeatsEmptyInClass(flight.getId(), seatClass);
                int totalSeats = (adult + child + infant);
                int ans = -1;
                if (emptySeats < totalSeats){
                    ans  = JOptionPane.showConfirmDialog(null, "The flight you have selected does " +
                                    "not have the requested number of seats. Do you want to add your name to the waiting list",
                            "Flight full", JOptionPane.YES_NO_CANCEL_OPTION);
                } else {
                    tout.setText(data2+data3+data4+data5+data9+data1+data6+data7+data8+data10);
                    tout.setEditable(false);
                    res.setText("Information saved Successfully.....");

                    ds.insertTicket(user, flight.getId(), seatClass, adult, child, infant,
                            Integer.parseInt(weight.getSelectedItem().toString()), wheelchair);
                }
                if (ans == 0){
                    ds.insertWaiting(user, flight.getId(), seatClass, totalSeats,
                            Integer.parseInt(weight.getSelectedItem().toString()), wheelchair);
                }
            }


        }

        //*********************** seating button functionality ****************
        if(e.getSource()==seating){

            if (!buttonClicked){
                buttonClicked = true;
                int emptySeats = ds.getSeatsEmptyInClass(flight.getId(), seatClass);
                int totalSeats = (adult + child + infant);
                int ans = -1;
                if (emptySeats < totalSeats){
                    ans  = JOptionPane.showConfirmDialog(null, "The flight you have selected does " +
                                    "not have the requested number of seats. Do you want to add your name to the waiting list",
                            "Flight full", JOptionPane.YES_NO_CANCEL_OPTION);
                } else {
                    System.out.println("Seating Chart");
                    new SeatingButtonsFrame(user, flight.getId(), seatClass, seatCount);
                }
                if (ans == 0){
                    ds.insertWaiting(user, flight.getId(), seatClass, totalSeats,
                            Integer.parseInt(weight.getSelectedItem().toString()), wheelchair);
                }
            } else new SeatingButtonsFrame(user, flight.getId(), seatClass, seatCount);


        }
        boolean close = ds.closeDB();
    }
}
