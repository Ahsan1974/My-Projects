package com.company;

import model.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;

class TicketDisplay extends JFrame implements ActionListener {

    JTable table;
    JLabel ReservationDetails,id,user,date,departurePlace,arrivalPlace,seatClass,baggage,label,label1,wheelChair,price,flightno,arrivaldate,plane;
    JTextField idText, userText, planeText, flightNoText, DepartureDateText, departurePlaceText, arrivalPlaceText,
            arrivalDateText, seatClassText, baggageText, wheelchairText, priceText;
    JButton Show, delete;
    int userID;
    JComboBox comboBox, comboBox_1;

    public static void main(String[] args){
        new TicketDisplay(1);
    }

    public TicketDisplay(int userID){
        this.userID = userID;

        setTitle("Ticket Information");
        getContentPane().setBackground(Color.WHITE);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(null);

        seatClass = new JLabel("Departure");
        seatClass.setFont(new Font("Tahoma", Font.PLAIN, 19));
        seatClass.setBounds(60, 100, 150, 27);
        add(seatClass);

        baggage = new JLabel("Arrival");
        baggage.setFont(new Font("Tahoma", Font.PLAIN, 19));
        baggage.setBounds(370, 100, 150, 27);
        add(baggage);



        Show = new JButton("SHOW");
        Show.setBounds(680, 100, 100, 30);
        Show.addActionListener(this);
        add(Show);

        delete = new JButton("DELETE");
        delete.setBounds(680, 150, 100, 30);
        delete.addActionListener(this);
        add(delete);

        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

        ReservationDetails = new JLabel("Ticket Information");
        ReservationDetails.setForeground(Color.BLACK);
        ReservationDetails.setFont(new Font("Tahoma", Font.PLAIN, 31));
        ReservationDetails.setBounds(280, 27, 359, 31);
        add(ReservationDetails);

        id = new JLabel("ID");
        id.setFont(new Font("Tahoma", Font.PLAIN, 13));
        id.setBounds(150, 160, 80, 25);
        add(id);

        idText = new JTextField(20);
        idText.setBounds(240,160,170,25);
        add(idText);

        user = new JLabel("User");
        user.setFont(new Font("Tahoma", Font.PLAIN, 13));
        user.setBounds(150, 190, 80, 25);
        add(user);

        userText = new JTextField(20);
        userText.setBounds(240,190,170,25);
        add(userText);

        plane = new JLabel("Plane");
        plane.setFont(new Font("Tahoma", Font.PLAIN, 13));
        plane.setBounds(150, 220, 80, 25);
        add(plane);

        planeText = new JTextField(20);
        planeText.setBounds(240,220,170,25);
        add(planeText);

        flightno = new JLabel("Flight No.");
        flightno.setFont(new Font("Tahoma", Font.PLAIN, 13));
        flightno.setBounds(150, 250, 80, 25);
        add(flightno);

        flightNoText = new JTextField(20);
        flightNoText.setBounds(240,250,170,25);
        add(flightNoText);

        departurePlace = new JLabel("Departure");
        departurePlace.setFont(new Font("Tahoma", Font.PLAIN, 13));
        departurePlace.setBounds(150, 280, 80, 25);
        add(departurePlace);

        departurePlaceText = new JTextField(20);
        departurePlaceText.setBounds(240,280,170,25);
        add(departurePlaceText);

        date = new JLabel("Date");
        date.setFont(new Font("Tahoma", Font.PLAIN, 13));
        date.setBounds(150, 310, 80, 25);
        add(date);

        DepartureDateText = new JTextField(20);
        DepartureDateText.setBounds(240,310,170,25);
        add(DepartureDateText);


        arrivalPlace = new JLabel("Arrival");
        arrivalPlace.setFont(new Font("Tahoma", Font.PLAIN, 13));
        arrivalPlace.setBounds(150, 340, 80, 25);
        add(arrivalPlace);

        arrivalPlaceText = new JTextField(20);
        arrivalPlaceText.setBounds(240,340,170,25);
        add(arrivalPlaceText);

        arrivaldate = new JLabel("Arrival_Date");
        arrivaldate.setFont(new Font("Tahoma", Font.PLAIN, 13));
        arrivaldate.setBounds(150, 370, 80, 25);
        add(arrivaldate);

        arrivalDateText = new JTextField(20);
        arrivalDateText.setBounds(240,370,170,25);
        add(arrivalDateText);

        seatClass = new JLabel("Seats");
        seatClass.setFont(new Font("Tahoma", Font.PLAIN, 13));
        seatClass.setBounds(150, 400, 80, 25);
        add(seatClass);

        seatClassText = new JTextField(20);
        seatClassText.setBounds(240,400,170,25);
        add(seatClassText);

        baggage = new JLabel("Baggage");
        baggage.setFont(new Font("Tahoma", Font.PLAIN, 13));
        baggage.setBounds(150, 430, 80, 25);
        add(baggage);

        baggageText = new JTextField(20);
        baggageText.setBounds(240,430,170,25);
        add(baggageText);

        wheelChair = new JLabel("Wheel_Chair");
        wheelChair.setFont(new Font("Tahoma", Font.PLAIN, 13));
        wheelChair.setBounds(150, 460, 80, 25);
        add(wheelChair);

        wheelchairText = new JTextField(20);
        wheelchairText.setBounds(240,460,170,25);
        add(wheelchairText);

        price = new JLabel("Price");
        price.setFont(new Font("Tahoma", Font.PLAIN, 13));
        price.setBounds(150, 490, 80, 25);
        add(price);

        priceText = new JTextField(20);
        priceText.setBounds(240,490,170,25);
        add(priceText);


        String[] items1 =  {
                "Karachi", "Lahore", "Islamabad",
                "Quetta", "Dubai", "New York City", "Kuala Lumpur",
                "Swat", "London", "Istanbul", "Moscow"
        };
        comboBox = new JComboBox(items1);
        comboBox.setBounds(170, 100, 150, 27);
        add(comboBox);


        String[] items2 =  {
                "Karachi", "Lahore", "Islamabad",
                "Quetta", "Dubai", "New York City", "Kuala Lumpur",
                "Swat", "London", "Istanbul", "Moscow"
        };
        comboBox_1 = new JComboBox(items2);
        comboBox_1.setBounds(450, 100, 150, 27);
        add(comboBox_1);

        table = new JTable();
        table.setBounds(38, 310, 770, 130);
        add(table);

        setSize(860,600);
        setLocation(400,200);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Datasource ds = new Datasource();
        ds.openDB();
        Ticket t = ds.getAllTicketsOfUser(userID, comboBox.getSelectedItem().toString(),
                comboBox_1.getSelectedItem().toString());
        Flight f = ds.getFlight(t.getFlight());
        User u = ds.findUser(userID);
        ArrayList<String> seats = ds.getSeatsOfUserInFlight(t.getFlight(), userID);
        StringBuilder sb = new StringBuilder();
        for (String seat: seats) {
            sb.append(seat + ",");
        }

        if (e.getSource() == Show){

            idText.setText(String.valueOf(t.getId()));
            userText.setText(u.getFirstName() + " " + u.getLastName());
            planeText.setText(f.getPlaneModel());
            flightNoText.setText(f.getFlightNum());
            DepartureDateText.setText(f.getDepartureDay() + "/" + f.getMonth() + "/2022" + "  " +
                    f.getDepartureHour() + ":" + f.getDepartureMin());
            departurePlaceText.setText(t.getDeparturePlace());
            arrivalDateText.setText(f.getArrivalDay() + "/" + f.getMonth() + "/2022" + "  " +
                    f.getArrivalHour() + ":" + f.getArrivalMin());
            arrivalPlaceText.setText(t.getArrivalPlace());
            seatClassText.setText(sb.toString());
            baggageText.setText(String.valueOf(t.getBaggage()));
            if (t.getWheelChair() == 0) wheelchairText.setText("No");
            else wheelchairText.setText("Yes");
            priceText.setText(String.valueOf(t.getPrice()));

        }

        if (e.getSource() == delete){
            ds.deleteTicket(t.getId());
            JOptionPane.showMessageDialog(null, "Ticket from " + t.getDeparturePlace() +
                    " to " + t.getArrivalPlace() + " has been canceled.");
            idText.setText("");
            userText.setText("");
            planeText.setText("");
            flightNoText.setText("");
            DepartureDateText.setText("");
            departurePlaceText.setText("");
            arrivalDateText.setText("");
            arrivalPlaceText.setText("");
            seatClassText.setText("");
            baggageText.setText("");
            wheelchairText.setText("");
            priceText.setText("");
        }
        ds.closeDB();
    }
}
