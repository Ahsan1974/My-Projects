package com.company;
import model.Datasource;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main_page extends JFrame implements ActionListener {
    public int user;
    JMenuBar menuBar;
    JMenu airlinesystemMenu;
    JMenu customerdetailsMenu;
    JMenu discoverMenu;
    JMenu ticketMenu;
    JMenuItem ticketinfoItem;
    JMenuItem ticketbookItem;
    JMenuItem flightinfoItem;
    JMenuItem informationitem;
    JMenuItem aboutusitem;
    JMenuItem cabinclassesitem;
    JMenuItem exitItem;

    Main_page(int user) {
        super("Airline Reservation System");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1950,1090);
        this.setLayout(new FlowLayout());

        this.user = user;
        //Image
        JLabel label = new JLabel();
        label.setIcon(new ImageIcon("Airline.jpg"));
        this.add(label);
        menuBar = new JMenuBar();
        airlinesystemMenu = new JMenu("Airline System");
        customerdetailsMenu = new JMenu("Customer Details");
        ticketMenu = new JMenu("Ticket");
        discoverMenu = new JMenu("Discover");


        ticketinfoItem = new JMenuItem("Ticket_Info");
        ticketbookItem = new JMenuItem("Ticket_Booking");
        flightinfoItem = new JMenuItem("Flight_Info");
        exitItem = new JMenuItem("Exit");
        informationitem = new JMenuItem("Information");
        aboutusitem = new JMenuItem("About us");
        cabinclassesitem = new JMenuItem("Cabin Classes");

        ticketinfoItem.addActionListener(this);
        ticketbookItem.addActionListener(this);
        flightinfoItem.addActionListener(this);
        exitItem.addActionListener(this);
        informationitem.addActionListener(this);
        aboutusitem.addActionListener(this);
        cabinclassesitem.addActionListener(this);



        airlinesystemMenu.setMnemonic(KeyEvent.VK_A); // Alt + a for airlinesystem
        customerdetailsMenu.setMnemonic(KeyEvent.VK_C); // Alt + c for customerdetails
        discoverMenu.setMnemonic(KeyEvent.VK_D); // Alt + d for discover
        ticketMenu.setMnemonic(KeyEvent.VK_T);  // Alt +t for ticket menu

        exitItem.setMnemonic(KeyEvent.VK_E);  // E for Exit
        ticketinfoItem.setMnemonic(KeyEvent.VK_T); // t for ticket
        flightinfoItem.setMnemonic(KeyEvent.VK_F);  // f for flight_info


        airlinesystemMenu.add(flightinfoItem);
        airlinesystemMenu.add(exitItem);
        ticketMenu.add(ticketinfoItem);
        ticketMenu.add(ticketbookItem);
        discoverMenu.add(informationitem);
        discoverMenu.add(cabinclassesitem);
        discoverMenu.add(aboutusitem);


        menuBar.add(airlinesystemMenu);
        menuBar.add(customerdetailsMenu);
        menuBar.add(discoverMenu);
        menuBar.add(ticketMenu);

        this.setJMenuBar(menuBar);

        this.setVisible(true);

        Datasource ds = new Datasource();
        boolean open = ds.openDB();
        boolean waitingList = ds.checkUserForWaitingList(user);
        if (waitingList){
            JOptionPane.showMessageDialog(null, "You have been assigned a ticket from the " +
                    "waiting list. Please check the ticket info section.");
        }
        boolean close = ds.closeDB();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == exitItem) {
            int response = JOptionPane.showConfirmDialog(null, "Do you want to exit?", "Alert", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (response == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        }
        if (e.getSource() == informationitem) {
            JOptionPane.showMessageDialog(null, "Project Objective\nThis software discovers passengers to look up flights between two points which can be domestic\nor international. The passengers can find and book tickets for flights through this software.\nDeveloped in Java, it is fairly easy to use software having a user-friendly interface.","Information", JOptionPane.INFORMATION_MESSAGE);
        }
        if (e.getSource() == aboutusitem) {
            JOptionPane.showMessageDialog(null, "Contact : xxxx-xxxxxx-x \nEmail : user123@gmail.com\nWebsite : www.ArsOfficial.com","About us", JOptionPane.INFORMATION_MESSAGE);
        }
        if (e.getSource() == cabinclassesitem) {
            JOptionPane.showMessageDialog(null, "Business Class:\nTaking Turkish hospitality to the skies! In Business Class, we make your trip the most pleasurable experience, with award-winning dishes, the latest in-\nflight entertainment system, and comfortable seating. By choosing Business Class, you too can feel special in the skies and travel in comfort as you enjoy\nthe miles you have earned through Miles&Smiles.\n\nEconomy Class:\nDiscover the privileges of Turkish Airlines at an affordable price. With Economy Class, we take your plans to travel at the price most suited to your budget\none step further.","Cabin Classes", JOptionPane.INFORMATION_MESSAGE);
        }
        if(e.getSource()==ticketbookItem){
            //JOptionPane.showMessageDialog(null, "This is Ticket Booking","About us", JOptionPane.INFORMATION_MESSAGE);
            new TicketSystem(user);
        }
        if (e.getSource() == ticketinfoItem){
            new TicketDisplay(user);
        }
    }
    }

//    FlightInfo.addActionListener(new ActionListener(){
//        public void actionPerformed(ActionEvent ae){
//            new Flight_Info();
//        }
//    });
//
//
//
//        CustomeDetails.addActionListener(new ActionListener(){
//        public void actionPerformed(ActionEvent ae){
//            new Customer_Details();
//        }
//    });
//
//        TicketInfo.addActionListener(new ActionListener(){
//        public void actionPerformed(ActionEvent ae){
//            new Ticket_Info():
//        }
//    });
//
//
//

