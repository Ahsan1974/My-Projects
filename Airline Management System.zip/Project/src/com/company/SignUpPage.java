package com.company;

import model.Datasource;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SignUpPage extends JFrame implements ActionListener {
    private Container c;
    private Container b;
    private JLabel title;
    private JLabel fname;
    private JTextField ftext;
    private JLabel sname;
    private JTextField stext;
    private JLabel email;
    private JTextField temail;
    private JLabel password;
    private JPasswordField tPassword;
    private JLabel cardInfo;
    private JTextField tcardInfo;
    private JLabel cnic;
    private JTextField tcnic;
    private JLabel phone;
    private JTextField tphone;
    private JLabel state;
    private JTextField tstate;
    private JLabel City;
    private JTextField tCity;
    private JButton Sub;
    private JButton log;
    private JButton can;
    private JLabel res;
    private JLabel LFullName;
    private JTextField tLFullName;
    private JLabel LEmail;
    private JTextField tLEmail;


    public SignUpPage(){
        setTitle("Sign Up");
        setBounds(300,90,900,700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        c=getContentPane();
        c.setLayout(null);
        title=new JLabel("Welcome To Airline Reservation System");
        title.setFont(new Font("Arial",Font.PLAIN,30));
        title.setSize(700,30);
        title.setLocation(200,20);
        c.add(title);

        title=new JLabel("Sign Up");
        title.setFont(new Font("Arial",Font.PLAIN,30));
        title.setSize(300,30);
        title.setLocation(400,60);
        c.add(title);

        fname=new JLabel("First Name");
        fname.setFont(new Font("Arial",Font.PLAIN,20));
        fname.setSize(150,28);
        fname.setLocation(250,100);
        c.add(fname);

        ftext=new JTextField();
        ftext.setFont(new Font("Arial",Font.PLAIN,20));
        ftext.setSize(200,28);
        ftext.setLocation(400,100);
        c.add(ftext);

        sname=new JLabel("Second Name");
        sname.setFont(new Font("Arial",Font.PLAIN,20));
        sname.setSize(150,28);
        sname.setLocation(250,150);
        c.add(sname);

        stext=new JTextField();
        stext.setFont(new Font("Arial",Font.PLAIN,20));
        stext.setSize(200,28);
        stext.setLocation(400,150);
        c.add(stext);

        email=new JLabel("Email");
        email.setFont(new Font("Arial",Font.PLAIN,20));
        email.setSize(150,28);
        email.setLocation(250,200);
        c.add(email);

        temail=new JTextField();
        temail.setFont(new Font("Arial",Font.PLAIN,20));
        temail.setSize(200,28);
        temail.setLocation(400,200);
        c.add(temail);

        password=new JLabel("Password");
        password.setFont(new Font("Arial",Font.PLAIN,20));
        password.setSize(150,28);
        password.setLocation(250,250);
        c.add(password);

        tPassword=new JPasswordField();
        tPassword.setFont(new Font("Arial",Font.PLAIN,20));
        tPassword.setSize(200,28);
        tPassword.setLocation(400,250);
        c.add(tPassword);

        cardInfo=new JLabel("Card Info");
        cardInfo.setFont(new Font("Arial",Font.PLAIN,20));
        cardInfo.setSize(150,28);
        cardInfo.setLocation(250,300);
        c.add(cardInfo);

        tcardInfo=new JTextField();
        tcardInfo.setFont(new Font("Arial",Font.PLAIN,20));
        tcardInfo.setSize(200,28);
        tcardInfo.setLocation(400,300);
        c.add(tcardInfo);

        cnic=new JLabel("CNIC Number");
        cnic.setFont(new Font("Arial",Font.PLAIN,20));
        cnic.setSize(150,28);
        cnic.setLocation(250,350);
        c.add(cnic);

        tcnic=new JTextField();
        tcnic.setFont(new Font("Arial",Font.PLAIN,20));
        tcnic.setSize(200,28);
        tcnic.setLocation(400,350);
        c.add(tcnic);

        phone=new JLabel("Phone Number");
        phone.setFont(new Font("Arial",Font.PLAIN,20));
        phone.setSize(150,28);
        phone.setLocation(250,400);
        c.add(phone);

        tphone=new JTextField();
        tphone.setFont(new Font("Arial",Font.PLAIN,20));
        tphone.setSize(200,28);
        tphone.setLocation(400,400);
        c.add(tphone);

        state=new JLabel("State Name");
        state.setFont(new Font("Arial",Font.PLAIN,20));
        state.setSize(150,28);
        state.setLocation(250,450);
        c.add(state);

        tstate=new JTextField();
        tstate.setFont(new Font("Arial",Font.PLAIN,20));
        tstate.setSize(200,28);
        tstate.setLocation(400,450);
        c.add(tstate);

        City=new JLabel("City Name");
        City.setFont(new Font("Arial",Font.PLAIN,20));
        City.setSize(150,28);
        City.setLocation(250,500);
        c.add(City);

        tCity=new JTextField();
        tCity.setFont(new Font("Arial",Font.PLAIN,20));
        tCity.setSize(200,28);
        tCity.setLocation(400,500);
        c.add(tCity);

        res=new JLabel("");
        res.setFont(new Font("Arial",Font.PLAIN,20));
        res.setSize(400,28);
        res.setLocation(400,550);
        c.add(res);

        Sub=new JButton("Sign Up");
        Sub.setFont(new Font("Arial",Font.PLAIN,15));
        Sub.setSize(100,40);
        Sub.setLocation(400,600);
        c.add(Sub);

        log=new JButton("Login");
        log.setFont(new Font("Arial",Font.PLAIN,15));
        log.setSize(100,40);
        log.setLocation(100,600);
        c.add(log);

        can=new JButton("Cancel");
        can.setFont(new Font("Arial",Font.PLAIN,15));
        can.setSize(100,40);
        can.setLocation(700,600);
        c.add(can);

        Sub.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerUser();
            }
        });
        can.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        log.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LpAirline();

            }
        });

        setVisible(true);




    }
    private void registerUser(){
        int user;
        String FirstName= ftext.getText();
            String SecondName= stext.getText();
            String Email=temail.getText();
            String CardInfo=tcardInfo.getText();
            String State=tstate.getText();
            String City=tCity.getText();
            String PhoneNumber=tphone.getText();
            String Password= new String(tPassword.getPassword());
            String CNICNumber=tcnic.getText();
            if(FirstName.isEmpty()||SecondName.isEmpty()||Email.isEmpty()||CardInfo.isEmpty()||State.isEmpty()
                    ||City.isEmpty()||PhoneNumber.isEmpty()||Password.isEmpty()||CNICNumber.isEmpty()){
                JOptionPane.showMessageDialog(this,"Please Enter all Fields","Try Again",JOptionPane.ERROR_MESSAGE);
                return;
            }
        Datasource ds = new Datasource();
        boolean open = ds.openDB();
        if (ds.findUser(Email)){
            JOptionPane.showMessageDialog(this,"Failed to register new User, enter a" +
                            " different email or use LOGIN button to go to login page",
                    "Try Again",JOptionPane.ERROR_MESSAGE);
        } else {
            user = ds.insertUser(FirstName,SecondName,Email, Password,CardInfo,CNICNumber,PhoneNumber, State,City);
            if(user>=0){
                res.setText("Sign Up Successfully.....");
                dispose();
                new Main_page(user);
            }else {
                JOptionPane.showMessageDialog(this,"Failed to register new User",
                        "Try Again",JOptionPane.ERROR_MESSAGE);
            }
        }
        boolean close = ds.closeDB();
    }
//    public User user;
//    private User addUserToDataBase(String FirstName,String SecondName,String Email,String CardInfo,String State,String PhoneNumber,String Password,String CNICNumber,String Cities){
//        User user=null;
//
//        return user;


    public static void main(String[] args) {
            new SignUpPage();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
