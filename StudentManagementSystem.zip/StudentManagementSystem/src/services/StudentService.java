package services;

import models.Student;
import utils.DatabaseUtil;

import java.util.ArrayList;
import java.util.List;

public class StudentService {
    private List<Student> students;

    // Constructor
    public StudentService(DatabaseUtil database) {
        this.students = new ArrayList<>();
    }

    // Add a new student
    public void addStudent(Student student) {
        students.add(student);
        System.out.println("Student added successfully: " + student.getName());
    }

    // Get a student by ID
    public Student getStudentById(int studentId) {
        for (Student student : students) {
            if (student.getStudentId() == studentId) {
                return student;
            }
        }
        System.out.println("Student with ID " + studentId + " not found.");
        return null;
    }

    // Update student details
    public void updateStudent(int studentId, String name, int age, String email, String phoneNumber) {
        Student student = getStudentById(studentId);
        if (student != null) {
            student.setName(name);
            student.setAge(age);
            student.setEmail(email);
            student.setPhoneNumber(phoneNumber);
            System.out.println("Student details updated successfully.");
        }
    }

    // Delete a student
    public void deleteStudent(int studentId) {
        Student student = getStudentById(studentId);
        if (student != null) {
            students.remove(student);
            System.out.println("Student removed successfully: " + student.getName());
        }
    }

    // Display all students
    public void displayAllStudents() {
        if (students.isEmpty()) {
            System.out.println("No students found.");
        } else {
            System.out.println("List of Students:");
            for (Student student : students) {
                student.displayStudentInfo();
                System.out.println("------------------");
            }
        }
    }
}


//package services;
//
//import models.Student;
//
//public class StudentService extends BaseService<Student> {
//    public Student getStudentById(int studentId) {
//        return findById(studentId).orElse(null);
//    }
//}


//
//package services;
//
//import models.Student;
//import java.util.List;
//
//public class StudentService extends BaseService<Student> implements IStudentService {
//    @Override
//    public void addStudent(Student student) {
//        add(student);
//    }
//
//    @Override
//    public List<Student> getAllStudents() {
//        return getAll();
//    }
//
//    @Override
//    public Student getStudentById(int studentId) {
//        return null;
//    }
//
//    @Override
//    public void deleteStudent(int studentId) {
//        findById(studentId).ifPresent(this::delete);
//    }
//}
