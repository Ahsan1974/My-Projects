package services;

import models.Enrollment;
import models.Student;
import models.Course;

import java.util.List;

public class ReportService {

    // Generate report for a student's enrollments
    public void generateStudentReport(Student student, List<Enrollment> enrollments) {
        System.out.println("Report for Student: " + student.getName() + " (ID: " + student.getStudentId() + ")");
        boolean hasEnrollments = false;

        for (Enrollment enrollment : enrollments) {
            if (enrollment.getStudent().getStudentId() == student.getStudentId()) {
                System.out.println("Enrolled in: " + enrollment.getCourse().getCourseName() +
                        " | Grade: " + enrollment.getGrade());
                hasEnrollments = true;
            }
        }

        if (!hasEnrollments) {
            System.out.println("No enrollments found for this student.");
        }
    }

    // Generate report for a course's enrollments
    public void generateCourseReport(Course course, List<Enrollment> enrollments) {
        System.out.println("Report for Course: " + course.getCourseName() + " (ID: " + course.getCourseId() + ")");
        boolean hasEnrollments = false;

        for (Enrollment enrollment : enrollments) {
            if (enrollment.getCourse().getCourseId() == course.getCourseId()) {
                System.out.println("Student: " + enrollment.getStudent().getName() +
                        " | Grade: " + enrollment.getGrade());
                hasEnrollments = true;
            }
        }

        if (!hasEnrollments) {
            System.out.println("No students enrolled in this course.");
        }
    }

    // Generate overall enrollment report
    public void generateOverallReport(List<Enrollment> enrollments) {
        if (enrollments.isEmpty()) {
            System.out.println("No enrollments found in the system.");
            return;
        }

        System.out.println("Overall Enrollment Report:");
        for (Enrollment enrollment : enrollments) {
            System.out.println("Student: " + enrollment.getStudent().getName() +
                    " | Course: " + enrollment.getCourse().getCourseName() +
                    " | Grade: " + enrollment.getGrade());
        }
    }
}
