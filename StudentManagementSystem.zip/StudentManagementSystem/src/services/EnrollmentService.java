package services;

import models.Enrollment;
import models.Student;
import models.Course;
import utils.DatabaseUtil;

import java.util.ArrayList;
import java.util.List;

public class EnrollmentService {
    private List<Enrollment> enrollments;

    // Constructor
    public EnrollmentService(DatabaseUtil database) {
        this.enrollments = new ArrayList<>();
    }

    // Enroll a student in a course
    public void enrollStudent(int enrollmentId, Student student, Course course, String enrollmentDate, String grade) {
        Enrollment enrollment = new Enrollment(enrollmentId, student, course, enrollmentDate, grade);
        enrollments.add(enrollment);
        System.out.println("Enrollment successful: " + student.getName() + " -> " + course.getCourseName());
    }

    // Get an enrollment by ID
    public Enrollment getEnrollmentById(int enrollmentId) {
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getEnrollmentId() == enrollmentId) {
                return enrollment;
            }
        }
        System.out.println("Enrollment with ID " + enrollmentId + " not found.");
        return null;
    }

    // Update enrollment details
    public void updateEnrollment(int enrollmentId, String enrollmentDate, String grade) {
        Enrollment enrollment = getEnrollmentById(enrollmentId);
        if (enrollment != null) {
            enrollment.setEnrollmentDate(enrollmentDate);
            enrollment.setGrade(grade);
            System.out.println("Enrollment details updated successfully.");
        }
    }

    // Remove an enrollment
    public void deleteEnrollment(int enrollmentId) {
        Enrollment enrollment = getEnrollmentById(enrollmentId);
        if (enrollment != null) {
            enrollments.remove(enrollment);
            System.out.println("Enrollment removed successfully.");
        }
    }

    // Display all enrollments
    public void displayAllEnrollments() {
        if (enrollments.isEmpty()) {
            System.out.println("No enrollments found.");
        } else {
            System.out.println("List of Enrollments:");
            for (Enrollment enrollment : enrollments) {
                enrollment.displayEnrollmentInfo();
                System.out.println("------------------");
            }
        }
    }
}




//package services;
//
//import models.Enrollment;
//
//public class EnrollmentService extends BaseService<Enrollment> {
//    public Enrollment getEnrollmentById(int enrollmentId) {
//        return findById(enrollmentId).orElse(null);
//    }
//}
