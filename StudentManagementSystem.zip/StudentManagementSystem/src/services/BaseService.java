package services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BaseService<T> {
    protected List<T> items = new ArrayList<>();

    public void add(T item) {
        items.add(item);
        System.out.println(item.getClass().getSimpleName() + " added successfully.");
    }

    public List<T> getAll() {
        return items;
    }

    public Optional<T> findById(int id) {
        return items.stream()
                .filter(item -> item.hashCode() == id)
                .findFirst();
    }

    public void delete(T item) {
        items.remove(item);
        System.out.println(item.getClass().getSimpleName() + " deleted successfully.");
    }
}





