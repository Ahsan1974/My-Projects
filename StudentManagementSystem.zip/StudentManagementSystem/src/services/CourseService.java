package services;

import models.Course;
import utils.DatabaseUtil;

import java.util.ArrayList;
import java.util.List;

public class CourseService {
    private List<Course> courses;

    // Constructor
    public CourseService(DatabaseUtil database) {
        this.courses = new ArrayList<>();
    }

    // Add a new course
    public void addCourse(Course course) {
        courses.add(course);
        System.out.println("Course added successfully: " + course.getCourseName());
    }

    // Get a course by ID
    public Course getCourseById(int courseId) {
        for (Course course : courses) {
            if (course.getCourseId() == courseId) {
                return course;
            }
        }
        System.out.println("Course with ID " + courseId + " not found.");
        return null;
    }

    // Update course details
    public void updateCourse(int courseId, String courseName, String courseCode, int creditHours, String instructorName) {
        Course course = getCourseById(courseId);
        if (course != null) {
            course.setCourseName(courseName);
            course.setCourseCode(courseCode);
            course.setCreditHours(creditHours);
            course.setInstructorName(instructorName);
            System.out.println("Course details updated successfully.");
        }
    }

    // Delete a course
    public void deleteCourse(int courseId) {
        Course course = getCourseById(courseId);
        if (course != null) {
            courses.remove(course);
            System.out.println("Course removed successfully: " + course.getCourseName());
        }
    }

    // Display all courses
    public void displayAllCourses() {
        if (courses.isEmpty()) {
            System.out.println("No courses found.");
        } else {
            System.out.println("List of Courses:");
            for (Course course : courses) {
                course.displayCourseInfo();
                System.out.println("------------------");
            }
        }
    }
}


//package services;
//
//import models.Course;
//
//public class CourseService extends BaseService<Course> {
//    public Course getCourseById(int courseId) {
//        return findById(courseId).orElse(null);
//    }
//}
