package services;

import models.Student;
import java.util.List;

public interface IStudentService {
    void addStudent(Student student);
    List<Student> getAllStudents();
    Student getStudentById(int studentId);
    void deleteStudent(int studentId);
}
