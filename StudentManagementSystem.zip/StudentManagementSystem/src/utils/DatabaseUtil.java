package utils;

import models.Student;
import models.Course;
import models.Enrollment;
import models.Instructor;

import java.util.ArrayList;
import java.util.List;

public class DatabaseUtil {
    private List<Student> students;
    private List<Course> courses;
    private List<Enrollment> enrollments;
    private List<Instructor> instructors;

    // Constructor (Simulating a simple in-memory database)
    public DatabaseUtil() {
        this.students = new ArrayList<>();
        this.courses = new ArrayList<>();
        this.enrollments = new ArrayList<>();
        this.instructors = new ArrayList<>();
    }

    // Student Methods
    public void addStudent(Student student) {
        students.add(student);
    }

    public List<Student> getAllStudents() {
        return students;
    }

    public Student getStudentById(int studentId) {
        for (Student student : students) {
            if (student.getStudentId() == studentId) {
                return student;
            }
        }
        return null;
    }

    // Course Methods
    public void addCourse(Course course) {
        courses.add(course);
    }

    public List<Course> getAllCourses() {
        return courses;
    }

    public Course getCourseById(int courseId) {
        for (Course course : courses) {
            if (course.getCourseId() == courseId) {
                return course;
            }
        }
        return null;
    }

    // Enrollment Methods
    public void addEnrollment(Enrollment enrollment) {
        enrollments.add(enrollment);
    }

    public List<Enrollment> getAllEnrollments() {
        return enrollments;
    }

    public Enrollment getEnrollmentById(int enrollmentId) {
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getEnrollmentId() == enrollmentId) {
                return enrollment;
            }
        }
        return null;
    }

    // Instructor Methods
    public void addInstructor(Instructor instructor) {
        instructors.add(instructor);
    }

    public List<Instructor> getAllInstructors() {
        return instructors;
    }

    public Instructor getInstructorById(int instructorId) {
        for (Instructor instructor : instructors) {
            if (instructor.getInstructorId() == instructorId) {
                return instructor;
            }
        }
        return null;
    }
}
