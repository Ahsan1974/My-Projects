package utils;

public class InputValidator {

    // Validate if a string is not empty or null
    public static boolean isValidString(String input) {
        return input != null && !input.trim().isEmpty();
    }

    // Validate if an integer is positive
    public static boolean isValidPositiveInteger(int number) {
        return number > 0;
    }

    // Validate if an email is in a proper format
    public static boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }

    // Validate if a phone number contains only digits and has a valid length
    public static boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber != null && phoneNumber.matches("\\d{10,15}");
    }

    // Validate if a grade is within acceptable values (A, B, C, D, F)
    public static boolean isValidGrade(String grade) {
        return grade != null && grade.matches("^[A-F]$");
    }
}
