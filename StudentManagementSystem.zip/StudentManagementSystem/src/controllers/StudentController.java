package controllers;

import models.Student;
import services.StudentService;
import utils.InputValidator;

import java.util.Scanner;

public class StudentController {
    private StudentService studentService;
    private Scanner scanner;

    // Constructor
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
        this.scanner = new Scanner(System.in);
    }

    // Method to handle adding a new student
    public void addStudent() {
        System.out.print("Enter Student ID: ");
        int studentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (!InputValidator.isValidPositiveInteger(studentId)) {
            System.out.println("Invalid ID. Must be a positive integer.");
            return;
        }

        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();
        if (!InputValidator.isValidString(name)) {
            System.out.println("Invalid Name. Cannot be empty.");
            return;
        }

        System.out.print("Enter Student Age: ");
        int age = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        if (!InputValidator.isValidPositiveInteger(age)) {
            System.out.println("Invalid Age. Must be a positive number.");
            return;
        }

        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        if (!InputValidator.isValidEmail(email)) {
            System.out.println("Invalid Email format.");
            return;
        }

        System.out.print("Enter Phone Number: ");
        String phoneNumber = scanner.nextLine();
        if (!InputValidator.isValidPhoneNumber(phoneNumber)) {
            System.out.println("Invalid Phone Number. Must be 10-15 digits.");
            return;
        }

        // Creating and adding student
        Student student = new Student(studentId, name, age, email, phoneNumber);
        studentService.addStudent(student);
    }

    // Method to display all students
    public void displayStudents() {
        studentService.displayAllStudents();
    }

    // Method to update a student's details
    public void updateStudent() {
        System.out.print("Enter Student ID to update: ");
        int studentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Student student = studentService.getStudentById(studentId);
        if (student == null) {
            System.out.println("Student not found.");
            return;
        }

        System.out.print("Enter New Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter New Age: ");
        int age = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter New Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter New Phone Number: ");
        String phoneNumber = scanner.nextLine();

        studentService.updateStudent(studentId, name, age, email, phoneNumber);
    }

    // Method to delete a student
    public void deleteStudent() {
        System.out.print("Enter Student ID to delete: ");
        int studentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        studentService.deleteStudent(studentId);
    }
}


//package controllers;
//
//import models.Student;
//import services.IStudentService;
//import utils.InputValidator;
//import java.util.Scanner;
//
//public class StudentController {
//    private IStudentService studentService;
//    private Scanner scanner;
//
//    public StudentController(IStudentService studentService) {
//        this.studentService = studentService;
//        this.scanner = new Scanner(System.in);
//    }
//
//    public void addStudent() {
//        System.out.print("Enter Student ID: ");
//        int studentId = scanner.nextInt();
//        scanner.nextLine(); // Consume newline
//
//        if (!InputValidator.isValidPositiveInteger(studentId)) {
//            System.out.println("Invalid ID. Must be a positive integer.");
//            return;
//        }
//
//        System.out.print("Enter Name: ");
//        String name = scanner.nextLine();
//        if (!InputValidator.isValidString(name)) {
//            System.out.println("Invalid Name. Cannot be empty.");
//            return;
//        }
//
//        System.out.print("Enter Email: ");
//        String email = scanner.nextLine();
//        if (!InputValidator.isValidEmail(email)) {
//            System.out.println("Invalid Email format.");
//            return;
//        }
//
//        studentService.addStudent(new Student(studentId, name, email));
//    }
//
//    public void displayStudents() {
//        studentService.getAllStudents().forEach(System.out::println);
//    }
//}
