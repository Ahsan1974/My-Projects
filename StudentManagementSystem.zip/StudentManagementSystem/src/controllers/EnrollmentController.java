package controllers;

import models.Enrollment;
import models.Student;
import models.Course;
import services.EnrollmentService;
import services.StudentService;
import services.CourseService;
import utils.InputValidator;

import java.util.List;
import java.util.Scanner;

public class EnrollmentController {
    private EnrollmentService enrollmentService;
    private StudentService studentService;
    private CourseService courseService;
    private Scanner scanner;

    // Constructor
    public EnrollmentController(EnrollmentService enrollmentService, StudentService studentService, CourseService courseService) {
        this.enrollmentService = enrollmentService;
        this.studentService = studentService;
        this.courseService = courseService;
        this.scanner = new Scanner(System.in);
    }

    // Method to enroll a student in a course
    public void enrollStudent() {
        System.out.print("Enter Enrollment ID: ");
        int enrollmentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (!InputValidator.isValidPositiveInteger(enrollmentId)) {
            System.out.println("Invalid Enrollment ID. Must be a positive integer.");
            return;
        }

        System.out.print("Enter Student ID: ");
        int studentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Student student = studentService.getStudentById(studentId);
        if (student == null) {
            System.out.println("Student not found.");
            return;
        }

        System.out.print("Enter Course ID: ");
        int courseId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Course course = courseService.getCourseById(courseId);
        if (course == null) {
            System.out.println("Course not found.");
            return;
        }

        System.out.print("Enter Enrollment Date (YYYY-MM-DD): ");
        String enrollmentDate = scanner.nextLine();
        if (!InputValidator.isValidString(enrollmentDate)) {
            System.out.println("Invalid date format.");
            return;
        }

        System.out.print("Enter Grade (A-F): ");
        String grade = scanner.nextLine();
        if (!InputValidator.isValidGrade(grade)) {
            System.out.println("Invalid Grade. Must be A, B, C, D, or F.");
            return;
        }

        enrollmentService.enrollStudent(enrollmentId, student, course, enrollmentDate, grade);
    }

    // Method to display all enrollments
    public void displayEnrollments() {
        enrollmentService.displayAllEnrollments();
    }

    // Method to update an enrollment's details
    public void updateEnrollment() {
        System.out.print("Enter Enrollment ID to update: ");
        int enrollmentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Enrollment enrollment = enrollmentService.getEnrollmentById(enrollmentId);
        if (enrollment == null) {
            System.out.println("Enrollment not found.");
            return;
        }

        System.out.print("Enter New Enrollment Date (YYYY-MM-DD): ");
        String enrollmentDate = scanner.nextLine();
        System.out.print("Enter New Grade (A-F): ");
        String grade = scanner.nextLine();

        enrollmentService.updateEnrollment(enrollmentId, enrollmentDate, grade);
    }

    // Method to delete an enrollment
    public void deleteEnrollment() {
        System.out.print("Enter Enrollment ID to delete: ");
        int enrollmentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        enrollmentService.deleteEnrollment(enrollmentId);
    }
}
