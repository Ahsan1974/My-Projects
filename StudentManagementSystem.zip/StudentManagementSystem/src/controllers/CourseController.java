package controllers;

import models.Course;
import services.CourseService;
import utils.InputValidator;

import java.util.Scanner;

public class CourseController {
    private CourseService courseService;
    private Scanner scanner;

    // Constructor
    public CourseController(CourseService courseService) {
        this.courseService = courseService;
        this.scanner = new Scanner(System.in);
    }

    // Method to handle adding a new course
    public void addCourse() {
        System.out.print("Enter Course ID: ");
        int courseId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (!InputValidator.isValidPositiveInteger(courseId)) {
            System.out.println("Invalid ID. Must be a positive integer.");
            return;
        }

        System.out.print("Enter Course Name: ");
        String courseName = scanner.nextLine();
        if (!InputValidator.isValidString(courseName)) {
            System.out.println("Invalid Course Name. Cannot be empty.");
            return;
        }

        System.out.print("Enter Course Code: ");
        String courseCode = scanner.nextLine();
        if (!InputValidator.isValidString(courseCode)) {
            System.out.println("Invalid Course Code. Cannot be empty.");
            return;
        }

        System.out.print("Enter Credit Hours: ");
        int creditHours = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        if (!InputValidator.isValidPositiveInteger(creditHours)) {
            System.out.println("Invalid Credit Hours. Must be a positive number.");
            return;
        }

        System.out.print("Enter Instructor Name: ");
        String instructorName = scanner.nextLine();
        if (!InputValidator.isValidString(instructorName)) {
            System.out.println("Invalid Instructor Name. Cannot be empty.");
            return;
        }

        // Creating and adding course
        Course course = new Course(courseId, courseName, courseCode, creditHours, instructorName);
        courseService.addCourse(course);
    }

    // Method to display all courses
    public void displayCourses() {
        courseService.displayAllCourses();
    }

    // Method to update a course's details
    public void updateCourse() {
        System.out.print("Enter Course ID to update: ");
        int courseId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Course course = courseService.getCourseById(courseId);
        if (course == null) {
            System.out.println("Course not found.");
            return;
        }

        System.out.print("Enter New Course Name: ");
        String courseName = scanner.nextLine();
        System.out.print("Enter New Course Code: ");
        String courseCode = scanner.nextLine();
        System.out.print("Enter New Credit Hours: ");
        int creditHours = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter New Instructor Name: ");
        String instructorName = scanner.nextLine();

        courseService.updateCourse(courseId, courseName, courseCode, creditHours, instructorName);
    }

    // Method to delete a course
    public void deleteCourse() {
        System.out.print("Enter Course ID to delete: ");
        int courseId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        courseService.deleteCourse(courseId);
    }
}
