import controllers.CourseController;
import controllers.EnrollmentController;
import controllers.StudentController;
import models.Student;
import services.CourseService;
import services.EnrollmentService;
import services.StudentService;
import utils.DatabaseUtil;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Initialize database and services
        DatabaseUtil database = new DatabaseUtil();
        StudentService studentService = new StudentService(database);
        CourseService courseService = new CourseService(database);
        EnrollmentService enrollmentService = new EnrollmentService(database);

        // Initialize controllers
        StudentController studentController = new StudentController(studentService);
        CourseController courseController = new CourseController(courseService);
        EnrollmentController enrollmentController = new EnrollmentController(enrollmentService, studentService, courseService);

        while (true) {
            System.out.println("\nStudent Management System");
            System.out.println("1. Manage Students");
            System.out.println("2. Manage Courses");
            System.out.println("3. Manage Enrollments");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    manageStudents(studentController, scanner);
                    break;
                case 2:
                    manageCourses(courseController, scanner);
                    break;
                case 3:
                    manageEnrollments(enrollmentController, scanner);
                    break;
                case 4:
                    System.out.println("Exiting program...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageStudents(StudentController studentController, Scanner scanner) {
        while (true) {
            System.out.println("\nStudent Management");
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Update Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    studentController.addStudent();
                    break;
                case 2:
                    studentController.displayStudents();
                    break;
                case 3:
                    studentController.updateStudent();
                    break;
                case 4:
                    studentController.deleteStudent();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageCourses(CourseController courseController, Scanner scanner) {
        while (true) {
            System.out.println("\nCourse Management");
            System.out.println("1. Add Course");
            System.out.println("2. View All Courses");
            System.out.println("3. Update Course");
            System.out.println("4. Delete Course");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    courseController.addCourse();
                    break;
                case 2:
                    courseController.displayCourses();
                    break;
                case 3:
                    courseController.updateCourse();
                    break;
                case 4:
                    courseController.deleteCourse();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageEnrollments(EnrollmentController enrollmentController, Scanner scanner) {
        while (true) {
            System.out.println("\nEnrollment Management");
            System.out.println("1. Enroll Student in a Course");
            System.out.println("2. View All Enrollments");
            System.out.println("3. Update Enrollment");
            System.out.println("4. Delete Enrollment");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    enrollmentController.enrollStudent();
                    break;
                case 2:
                    enrollmentController.displayEnrollments();
                    break;
                case 3:
                    enrollmentController.updateEnrollment();
                    break;
                case 4:
                    enrollmentController.deleteEnrollment();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
