package models;

public class Enrollment {
    private int enrollmentId;
    private Student student;
    private Course course;
    private String enrollmentDate;
    private String grade;

    // Constructor
    public Enrollment(int enrollmentId, Student student, Course course, String enrollmentDate, String grade) {
        this.enrollmentId = enrollmentId;
        this.student = student;
        this.course = course;
        this.enrollmentDate = enrollmentDate;
        this.grade = grade;
    }

    // Getters and Setters
    public int getEnrollmentId() {
        return enrollmentId;
    }

    public void setEnrollmentId(int enrollmentId) {
        this.enrollmentId = enrollmentId;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public String getEnrollmentDate() {
        return enrollmentDate;
    }

    public void setEnrollmentDate(String enrollmentDate) {
        this.enrollmentDate = enrollmentDate;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    // Display Enrollment Info
    public void displayEnrollmentInfo() {
        System.out.println("Enrollment ID: " + enrollmentId);
        System.out.println("Student: " + student.getName() + " (ID: " + student.getStudentId() + ")");
        System.out.println("Course: " + course.getCourseName() + " (ID: " + course.getCourseId() + ")");
        System.out.println("Enrollment Date: " + enrollmentDate);
        System.out.println("Grade: " + grade);
    }
}
